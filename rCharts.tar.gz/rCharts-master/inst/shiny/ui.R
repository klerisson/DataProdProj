require(rCharts)
shinyUI(bootstrapPage(
  showOutput("show")
))